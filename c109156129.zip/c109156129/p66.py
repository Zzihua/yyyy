# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 16:41:28 2021

@author: hzizhua
"""

'p66 共同出現的英文字母'

a=str(input("請輸入string_a:"))
b=str(input("請輸入string_b:"))
ab=set(a)&set(b)
list1=list(ab)
list1.sort()
if len(list1)==0:
    print("N")
else:
    for i in range(len(list1)):
        print(list1[i],end="")
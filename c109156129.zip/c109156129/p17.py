# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 14:40:13 2021

@author: hzizhua
"""

'p17 撲克牌13點'

a=list(input())
num=0
for i in range(0,10,2):
    if a[i]=="A":
        num=num+1
    elif a[i]=="J":
        num=num+11
    elif a[i]=="Q":
        num=num+12
    elif a[i]=="K":
        num=num+13
    else:
        a[i]=int(a[i])
        num=num+a[i]
print(num)
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 16:14:12 2021

@author: hzizhua
"""

'p65 共同朋友的數量'

a=list(input("請輸入A的好友:"))
b=list(input("請輸入B的好友:"))
print(len(set(a)&set(b))-1)

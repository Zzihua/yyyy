# -*- coding: utf-8 -*-
"""
Created on Sat Apr  3 15:55:35 2021

@author: hzizhua
"""

'p44 占卜運勢'

m=int(input(""))
d=int(input(""))
s=(m*2+d)%3
list1=["普通","吉","大吉"]
for i in range(3):
    if (s==i):
        print(list1[i])
        
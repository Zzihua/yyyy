# -*- coding: utf-8 -*-
"""
Created on Wed Dec 23 15:21:47 2020

@author: hzizhua
"""
num=int(input("請輸入階層值M:"))
a=1
i=1
while(num>a):
    a=a*i
    i=i+1
    if(a>num):
        break
print("超過M為",str(num),"的最小階層N值為:",str(i-1))
    
    
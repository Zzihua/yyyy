# -*- coding: utf-8 -*-
"""
Created on Wed Dec 23 15:47:54 2020

@author: hzizhua
"""

word=input("輸入一字元為:")
if(word==word[::-1]):
    print("YES")
else:
    print("NO")

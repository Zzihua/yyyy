# -*- coding: utf-8 -*-
"""
Created on Wed Dec 23 21:18:21 2020

@author: hzizhua
"""

word=str(input("輸入一字串為:"))
a=0
for i in range(len(word)):
    a=a+1
print("There are",str(a),"characters")

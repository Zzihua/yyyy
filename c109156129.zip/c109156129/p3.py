# -*- coding: utf-8 -*-
"""
Created on Tue Dec 22 23:04:42 2020

@author: hzizhua
"""

num=int(input())
if((num-2010)%12==0):
    print("tiger")
elif((num-2010)%12==1):
    print("rabbit")
elif((num-2010)%12==2):
    print("dragon")
elif((num-2010)%12==3):
    print("snake")
elif((num-2010)%12==4):
    print("horse")
elif((num-2010)%12==5):
    print("sheep")
elif((num-2010)%12==6):
    print("monkey")
elif((num-2010)%12==7):
    print("rooster")
elif((num-2010)%12==8):
    print("dog")
elif((num-2010)%12==9):
    print("pig")
elif((num-2010)%12==10):
    print("rat")
elif((num-2010)%12==11):
    print("ox")
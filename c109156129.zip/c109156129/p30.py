# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 15:11:29 2021

@author: hzizhua
"""

'p30 販賣機'

coin=int(input("小明身上有幾元:"))
list1=[]
num=0
how=int(input("販賣機有幾種飲料:"))
for i in range(how):
    list1.append(int(input()))
for j in range(how):
    if list1[j]<=coin:
        num=num+1
print(num)
        
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 23 22:12:46 2020

@author: hzizhua
"""

list1=[]
list2=[]
n=int(input("輸入n值:"))
for i in range(n):
    name=str(input("請輸入姓名:"))
    email=str(input("請輸入電子郵件:"))
    list1.append(name)
    list2.append(email)
Who=str(input("請輸入要查詢電子郵件的姓名:"))
for i in range(len(list1)):
    while(list1[i]==Who):
        print(Who,"電子郵件帳號為",list2[i])
        break


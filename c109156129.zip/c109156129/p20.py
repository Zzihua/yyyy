# -*- coding: utf-8 -*-
"""
Created on Wed Dec 23 21:23:23 2020

@author: hzizhua
"""

num=str(input("輸入查詢的學號為:"))
dict1={"123":"Tom","456":"Cat","789":"Nana","321":"Lim","654":"Won"}
key=list(dict1.keys())
value=list(dict1.values())
if(num==key[0]):
    print("學生資料為:",key[0],value[0],"DTGD")
elif(num==key[1]):
    print("學生資料為:",key[1],value[1],"CSIE")
elif(num==key[2]):
    print("學生資料為:",key[2],value[2],"ASIE")
elif(num==key[3]):
    print("學生資料為:",key[3],value[3],"DBA")
elif(num==key[4]):
    print("學生資料為:",key[4],value[4],"FDD")

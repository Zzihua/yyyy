# -*- coding: utf-8 -*-
"""
Created on Sat Apr  3 15:28:13 2021

@author: hzizhua
"""

'31 期末成績'

list1=[]
chi=int(input("國文:"))
eng=int(input("英文:"))
ma=int(input("微積分:"))
gym=int(input("體育:"))
py=int(input("程式設計:"))
list1.append(chi)
list1.append(eng)
list1.append(ma)
list1.append(gym)
list1.append(py)
list1=[chi,eng,ma,gym,py]
list2=sorted(list1)
list2.reverse()
print("平均分數:",(chi+eng+ma+gym+py)/5)
if (list2[0]==chi):
    print("最高分科目:國文",chi,"分")
elif(list2[0]==eng):
    print("最高分科目:英文",eng,"分")
elif(list2[0]==ma):
    print("最高分科目:微積分",ma,"分")
elif(list2[0]==gym):
    print("最高分科目:體育",gym,"分")
elif(list2[0]==py):
    print("最高分科目:程式設計",py,"分")
if (list2[4]==chi):
    print("最低分科目:國文",chi,"分")
elif(list2[4]==eng):
    print("最低分科目:英文",eng,"分")
elif(list2[4]==ma):
    print("最低分科目:微積分",ma,"分")
elif(list2[4]==gym):
    print("最低分科目:體育",gym,"分")
elif(list2[4]==py):
    print("最低分科目:程式設計",py,"分")


# -*- coding: utf-8 -*-
"""
Created on Tue Dec 22 23:02:48 2020

@author: hzizhua
"""

num=int(input())
if(num<=120):
    print("Summer month:",(num*2.10))
    print("Non-Summer month:",(num*2.10))
elif(num>=121 and num<=330):
    print("Summer month:",(num-120)*3.02+(120*2.10))
    print("Non-Summer month:",(num-120)*2.68+(120*2.10))
elif(num>=331 and num<=500):
    print("Summer month:",(num-330)*4.39+(210*3.02)+(120*2.10))
    print("Non-Summer month:",(num-330)*3.61+(210*2.68)+(120*2.10))
elif(num>=501 and num<=700):
    print("Summer month:",(num-500)*4.97+(170*4.39)+(210*3.02)+(120*2.10))
    print("Non-Summer month:",(num-500)*4.01+(170*3.61)+(210*2.68)+(120*2.10))
elif(num>=701):
    print("Summer month:",(num-700)*5.63+(200*4.97)+(170*4.39)+(210*3.02)+(120*2.10))
    print("Non-Summer month:",(num-700)*4.50+(200*4.01)+(170*3.61)+(210*2.68)+(120*2.10))

# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 15:56:32 2021

@author: hzizhua
"""

'p43 電腦數量'

class1=int(input())
list1=[]
for i in range(class1):
    list1.append(input())
list1.sort()
print(list1[class1-1])
# -*- coding: utf-8 -*-
"""
Created on Sat Apr  3 15:05:13 2021

@author: hzizhua
"""

'28 猜數字'

ans=list("1234")
gue=list(input(""))
a=0
b=0
for i in range(4):
    if (ans[i]==gue[i]):
        a=a+1
    else:
        b=b+1
print(a,"A",b,"B")